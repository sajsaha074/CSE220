import numpy as np

def remove(arr, index):
    for i in range(index, len(arr)-1):
        arr[i] = arr[i+1]
    arr[len(arr)-1] = 0

array = np.array([34,67,89,56,70,19], dtype=np.float64)
#output = [34.67,89.56,70.19,0,0,0]

print("Original array:")
print(array)

for i in range(0, len(array), 2):
    array[i] = array[i] + array[i+1]/100.0
    print(i, array)

to_remove = int(len(array)/2)

for i in range(to_remove):
    remove(array, i+1)
    print(i+1, array)

print("New array:")
print(array)

# 2. 3*8 + 4 = 28